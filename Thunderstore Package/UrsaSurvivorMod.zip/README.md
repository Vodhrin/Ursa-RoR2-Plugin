## Ursa Surivor
-Adds Ursa from Dota 2 as a playable survivor.
-Early development.
-The character is not a 1:1 port and has some changes from the original.
-Works in multiplayer.

![](https://i.imgur.com/1Q1FT9b.png)

## Feedback/Engagement
If you would like to leave feedback or discuss any of our mods with us, you can find us at:
https://discord.gg/bYGV6s6

## Changelog

0.1.0
-Initial release.